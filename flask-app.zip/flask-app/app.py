from flask import Flask, render_template, request
import os
import time
import requests
import PyPDF2

app = Flask(__name__)

# Global dictionary mapping subject codes to subject names
subject_codes = {
    "9700": "biology",
    "9701": "chemistry",
    "9702": "physics",
    "9704": "art-and-design",
    "9705": "design-and-technology",
    "9706": "accounting",
    "9707": "business",
    "9708": "economics",
    "9709": "mathematics",
    "9609": "business",
    "9618": "computer-science",
    "9626": "information-technology",
    "9631": "design-and-textiles",
    "9639": "travel-and-tourism",
    "9686": "urdu",
    "9695": "literature-in-english",
    "9696": "geography",
    "9697": "history",
    "9698": "psychology",
    "9699": "sociology",
    "9715": "chinese",
    "9716": "french",
    "9717": "german",
    "9718": "portuguese",
    "9719": "spanish",
    "9720": "food-studies",
    "9721": "geography",
    "9722": "global-perspectives",
    "9723": "history",
    "9724": "islamic-studies",
    "9725": "law",
    "9726": "marine-science",
    "9727": "further-mathematics",
    "9728": "music",
    "9729": "physical-education",
    "9731": "psychology",
    "9732": "sociology",
    "9733": "spanish",
    "9734": "travel-and-tourism",
    "9735": "urdu",
    "9736": "world-development",
    "9481": "digital-media-and-design",
    "9482": "drama",
    "8291": "environmental-management",
    "9093": "english-language",
    "8021": "english-general-paper"
}


def create_directory(dir_path):
    os.makedirs(dir_path, exist_ok=True)
    print(f"Directory ready: {dir_path}")


def download_file(url, file_path):
    try:
        response = requests.get(url, stream=True, timeout=30)
        response.raise_for_status()
        content_type = response.headers.get('Content-Type', '')
        if 'application/pdf' not in content_type and 'binary/octet-stream' not in content_type:
            print(
                f"Warning: URL {url} may not be a PDF (Content-Type: {content_type})")
        total_size = int(response.headers.get('Content-Length', 0))
        with open(file_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        if total_size and os.path.getsize(file_path) != total_size:
            print(f"Warning: Size mismatch in {file_path}")
            return False
        with open(file_path, 'rb') as f:
            if f.read(4) != b'%PDF':
                print(f"Warning: {file_path} is not a valid PDF.")
                return False
        print(f"Downloaded: {file_path}")
        return True
    except Exception as e:
        print(f"Error downloading {url}: {e}")
        return False


def is_blank_page(page, page_num):
    if page_num == 0:
        return False
    text = page.extract_text() or ""
    lt = text.lower()
    if "blank page" in lt or "additional page" in lt:
        print(f"Page {page_num+1} marked as blank/additional.")
        return True
    if not text.strip() or len(text.strip()) < 10:
        return not (hasattr(page, 'images') and page.images)
    if len(text.strip()) < 20 and (text.strip().isdigit() or len(text.strip().split()) <= 3):
        return True
    return False


def remove_blank_pages(input_pdf, output_pdf):
    try:
        with open(input_pdf, 'rb') as f:
            if f.read(4) != b'%PDF':
                print(f"{input_pdf} is not a valid PDF.")
                return False
            f.seek(0)
            reader = PyPDF2.PdfReader(f)
            writer = PyPDF2.PdfWriter()
            for i, page in enumerate(reader.pages):
                if not is_blank_page(page, i):
                    writer.add_page(page)
            with open(output_pdf, 'wb') as out_f:
                writer.write(out_f)
        print(f"Processed and removed blank pages from: {input_pdf}")
        return True
    except Exception as e:
        print(f"Error processing {input_pdf}: {e}")
        return False


def merge_pdfs(pdf_list, output_file):
    try:
        merger = PyPDF2.PdfMerger()
        for pdf in pdf_list:
            merger.append(pdf)
        merger.write(output_file)
        merger.close()
        print(f"Merged PDFs into: {output_file}")
        return True
    except Exception as e:
        print(f"Error merging PDFs: {e}")
        return False


def get_subject_name(syllabus_code):
    return subject_codes.get(syllabus_code, "unknown-subject")


def scrape_cambridge_papers(syllabus_code, component_code, years, series):
    subject = get_subject_name(syllabus_code)
    base_dir = os.path.join(
        "Cambridge_Past_Papers", f"Subject_{syllabus_code}", f"Component_{component_code}")
    create_directory(base_dir)
    temp_dir = os.path.join(base_dir, "temp")
    create_directory(temp_dir)
    downloaded = []
    for year in years:
        suffix = year[-2:]
        for sess in series:
            url = f"https://pastpapers.papacambridge.com/directories/CAIE/CAIE-pastpapers/upload/{syllabus_code}_{sess}{suffix}_qp_{component_code}.pdf"
            file_name = f"{syllabus_code}_{sess}{suffix}_qp_{component_code}.pdf"
            file_path = os.path.join(temp_dir, file_name)
            print(f"Attempting download from: {url}")
            if download_file(url, file_path):
                downloaded.append(file_path)
            else:
                print(f"Download failed for: {url}")
            time.sleep(1)
        # Fallback: if no paper was downloaded for this year, try GCE Guide
        if not any(suffix in f for f in downloaded):
            level = "a-levels" if int(component_code) >= 40 else "as-levels"
            for sess in series:
                url = f"https://papers.gceguide.cc/{level}/{subject}-({syllabus_code})/{year}/{syllabus_code}_{sess}{suffix}_qp_{component_code}.pdf"
                file_name = f"{syllabus_code}_{sess}{suffix}_qp_{component_code}_gce.pdf"
                file_path = os.path.join(temp_dir, file_name)
                print(f"Fallback download from: {url}")
                if download_file(url, file_path):
                    downloaded.append(file_path)
                    break
                time.sleep(1)
    print(
        f"Total files downloaded for component {component_code}: {len(downloaded)}")
    return downloaded, base_dir


def process_request_form(form):
    # Extract fields from the form
    syllabus_code = form.get('subject_code')
    component_codes_raw = form.get('component_codes', '')
    component_codes = [code.strip()
                       for code in component_codes_raw.split(',') if code.strip()]
    years = form.getlist('years')
    series = form.getlist('sessions')
    remove_blank = True if form.get('remove_blank') else False
    remove_additional = True if form.get('remove_additional') else False

    print(f"Processing form with subject: {syllabus_code}")
    print(f"Component Codes: {component_codes}")
    print(f"Years: {years}, Sessions: {series}")
    print(
        f"Remove Blank: {remove_blank}, Remove Additional: {remove_additional}")

    all_downloaded_files = []
    common_base_dir = os.path.join(
        "Cambridge_Past_Papers", f"Subject_{syllabus_code}")
    create_directory(common_base_dir)

    # Process each component code
    for comp_code in component_codes:
        downloaded_files, _ = scrape_cambridge_papers(
            syllabus_code, comp_code, years, series)
        all_downloaded_files.extend(downloaded_files)

    if not all_downloaded_files:
        return None

    processed_files = []
    for pdf in all_downloaded_files:
        proc_pdf = pdf.replace(".pdf", "_processed.pdf")
        if remove_blank or remove_additional:
            if remove_blank_pages(pdf, proc_pdf):
                processed_files.append(proc_pdf)
        else:
            processed_files.append(pdf)
    if processed_files:
        merged_path = os.path.join(
            common_base_dir, f"{syllabus_code}_combined_papers.pdf")
        merge_pdfs(processed_files, merged_path)
        # Clean up temporary files
        for file in processed_files + all_downloaded_files:
            try:
                os.remove(file)
            except Exception as e:
                print(e)
        try:
            temp_dir = os.path.join(common_base_dir, "temp")
            os.rmdir(temp_dir)
        except Exception as e:
            print(e)
        return merged_path
    else:
        return None


@app.route('/')
def index():
    return render_template('past_papers_form.html', subject_codes=subject_codes)


@app.route('/generate', methods=['POST'])
def generate():
    merged_pdf_path = process_request_form(request.form)
    if merged_pdf_path and os.path.exists(merged_pdf_path):
        # Instead of sending the file using send_file, we render the template
        # with a success message. You may also include a link to download
        # the file if desired.
        success_message = "PDF combined successfully."
        return render_template('past_papers_form.html', subject_codes=subject_codes, success_message=success_message)
    else:
        error_message = "Error generating combined PDF. Please try again."
        return render_template('past_papers_form.html', subject_codes=subject_codes, error_message=error_message), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
